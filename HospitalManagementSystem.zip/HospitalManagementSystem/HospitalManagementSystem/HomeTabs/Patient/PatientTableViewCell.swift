//
//  PatientTableViewCell.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class PatientTableViewCell: UITableViewCell
{
    @IBOutlet weak var label_PatName: UILabel!

    @IBOutlet weak var label_PatAge: UILabel!
    @IBOutlet weak var label_PatGender: UILabel!
    
    @IBOutlet weak var label_PatAddress: UILabel!
    
    @IBOutlet weak var label_PatArrivalDate: UILabel!
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
