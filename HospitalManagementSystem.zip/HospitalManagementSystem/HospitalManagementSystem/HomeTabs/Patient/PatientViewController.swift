//
//  PatientViewController.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class PatientViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var tableview_Patient: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        title = "PATIENT"
        
        tableview_Patient.delegate = self
        tableview_Patient.dataSource = self
        
        navigationBarButton()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        DispatchQueue.main.async
        {
            self.tableview_Patient.reloadData()
        }
    }
    
    func navigationBarButton()
    {
        //Left bar button item
        let leftButton : UIBarButtonItem = UIBarButtonItem(title: "BACK", style: UIBarButtonItemStyle.plain, target: self, action: #selector(leftButtonTapped))
        leftButton.tintColor = UIColor.black
        
        self.navigationItem.leftBarButtonItem = leftButton
        //Ends
        
        //Right bar button item
        let rightButton : UIBarButtonItem = UIBarButtonItem(title: "ADD", style: UIBarButtonItemStyle.plain, target: self, action: #selector(rightButtonTapped))
        rightButton.tintColor = UIColor.black
        
        self.navigationItem.rightBarButtonItem = rightButton
        //Ends
    }
    
    @objc func leftButtonTapped()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func rightButtonTapped()
    {
        self.performSegue(withIdentifier: "addpatientview", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if(segue.identifier == "addpatientview")
        {
            let addpatientview = segue.destination as! AddPatientViewController
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return MainFile.patName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellidentifier_patient") as! PatientTableViewCell
        
        cell.label_PatName.text = MainFile.patName[indexPath.row]
        cell.label_PatAge.text = MainFile.patAge[indexPath.row]
        cell.label_PatGender.text = MainFile.patSex[indexPath.row]
        cell.label_PatAddress.text = MainFile.patAddress[indexPath.row]
        cell.label_PatArrivalDate.text = MainFile.patArrivalDate[indexPath.row]

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 170.0
    }
}
