//
//  AddPatientViewController.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class AddPatientViewController: UIViewController
{
    @IBOutlet weak var textfield_PatName: UITextField!
    @IBOutlet weak var textfield_PatArrivalDate: UITextField!
    @IBOutlet weak var textfield_Address: UITextField!
    @IBOutlet weak var textfield_PatGender: UITextField!
    @IBOutlet weak var textfield_PatAge: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        title = "ADD PATIENT"
        
        //Gestures
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tapGestureMethod(_:)))
        view.addGestureRecognizer(tapGesture)
        //Ends
        
        navigationBarButton()
    }
    
    @objc func tapGestureMethod(_ sender: UITapGestureRecognizer)
    {
        self.view.endEditing(true)
    }
    
    func navigationBarButton()
    {
        //Left bar button item
        let leftButton : UIBarButtonItem = UIBarButtonItem(title: "BACK", style: UIBarButtonItemStyle.plain, target: self, action: #selector(leftButtonTapped))
        leftButton.tintColor = UIColor.black
        
        self.navigationItem.leftBarButtonItem = leftButton
        //Ends
        
        //Left bar button item
        let rightButton : UIBarButtonItem = UIBarButtonItem(title: "SAVE", style: UIBarButtonItemStyle.plain, target: self, action: #selector(rightButtonTapped))
        rightButton.tintColor = UIColor.black
        
        self.navigationItem.rightBarButtonItem = rightButton
        //Ends
    }
    
    @objc func leftButtonTapped()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func rightButtonTapped()
    {
        self.view.endEditing(true)
        
        if(textfield_PatName.text?.isEmpty == false && textfield_PatAge.text?.isEmpty == false && textfield_PatGender.text?.isEmpty == false && textfield_Address.text?.isEmpty == false && textfield_PatArrivalDate.text?.isEmpty == false)
        {
            let alertController = UIAlertController(title: "Hospital Management", message: "Do you really want to add this patient?", preferredStyle: UIAlertControllerStyle.alert)
            
            alertController.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.destructive) {
                (result : UIAlertAction) -> Void in
                
                MainFile.patName.append(self.textfield_PatName.text!)
                MainFile.patAge.append(self.textfield_PatAge.text!)
                MainFile.patSex.append(self.textfield_PatGender.text!)
                MainFile.patAddress.append(self.textfield_Address.text!)
                MainFile.patArrivalDate.append(self.textfield_PatArrivalDate.text!)

                self.navigationController?.popViewController(animated: true)
            })
            alertController.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default))
            
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Hospital Management", message: "Please fill all fields to perform this operation.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
}
