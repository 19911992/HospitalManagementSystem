//
//  MedicineTableViewCell.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-10.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class MedicineTableViewCell: UITableViewCell
{
    @IBOutlet weak var label_MedName: UILabel!
    @IBOutlet weak var label_MedQuantity: UILabel!
    @IBOutlet weak var label_MedPrice: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
