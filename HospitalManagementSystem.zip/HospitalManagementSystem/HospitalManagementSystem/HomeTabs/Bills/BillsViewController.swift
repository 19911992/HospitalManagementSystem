//
//  BillsViewController.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class BillsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var tableview_Bills: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        title = "BILLS"
        
        navigationBarButton()
        
        tableview_Bills.delegate = self
        tableview_Bills.dataSource = self
    }
    
    func navigationBarButton()
    {
        //Left bar button item
        let leftButton : UIBarButtonItem = UIBarButtonItem(title: "BACK", style: UIBarButtonItemStyle.plain, target: self, action: #selector(leftButtonTapped))
        leftButton.tintColor = UIColor.black
        
        self.navigationItem.leftBarButtonItem = leftButton
        //Ends
    }
    
    @objc func leftButtonTapped()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return MainFile.billDate.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellidentifier_Bills") as! BillsTableViewCell
        
        cell.label_billsDate.text = MainFile.billDate[indexPath.row]
        cell.label_billsPatName.text = MainFile.billPatName[indexPath.row]
        cell.label_billsAssignedDoc.text = MainFile.billPatAssignDoc[indexPath.row]
        cell.label_billsRoomNo.text = MainFile.billPatRoom[indexPath.row]
        cell.label_billsAmount.text = MainFile.billAmount[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 160.0
    }
}
