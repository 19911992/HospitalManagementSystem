//
//  EmployeeTableViewCell.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-09.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class EmployeeTableViewCell: UITableViewCell
{
    @IBOutlet weak var label_EmpName: UILabel!
    @IBOutlet weak var label_EmpAge: UILabel!
    @IBOutlet weak var label_EmpDesignation: UILabel!
    @IBOutlet weak var label_EmpAddress: UILabel!
    @IBOutlet weak var label_EmpShift: UILabel!
    @IBOutlet weak var label_EmpGender: UILabel!

    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
