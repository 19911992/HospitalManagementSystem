//
//  AddEmployeeViewController.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-10.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class AddEmployeeViewController: UIViewController
{
    @IBOutlet weak var textfield_EmpName: UITextField!
    @IBOutlet weak var textfield_EmpAge: UITextField!
    @IBOutlet weak var textfield_EmpGender: UITextField!
    @IBOutlet weak var textfield_EmpDesignation: UITextField!
    @IBOutlet weak var textfield_EmpShift: UITextField!
    @IBOutlet weak var textfield_EmpAddress: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        title = "ADD EMPLOYEE"
        
        //Gestures
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tapGestureMethod(_:)))
        view.addGestureRecognizer(tapGesture)
        //Ends
        
        navigationBarButton()
    }
    
    @objc func tapGestureMethod(_ sender: UITapGestureRecognizer)
    {
        self.view.endEditing(true)
    }
    
    func navigationBarButton()
    {
        //Left bar button item
        let leftButton : UIBarButtonItem = UIBarButtonItem(title: "BACK", style: UIBarButtonItemStyle.plain, target: self, action: #selector(leftButtonTapped))
        leftButton.tintColor = UIColor.black
        
        self.navigationItem.leftBarButtonItem = leftButton
        //Ends
        
        //Left bar button item
        let rightButton : UIBarButtonItem = UIBarButtonItem(title: "SAVE", style: UIBarButtonItemStyle.plain, target: self, action: #selector(rightButtonTapped))
        rightButton.tintColor = UIColor.black
        
        self.navigationItem.rightBarButtonItem = rightButton
        //Ends
    }
    
    @objc func leftButtonTapped()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func rightButtonTapped()
    {
        self.view.endEditing(true)
        
        if(textfield_EmpName.text?.isEmpty == false && textfield_EmpAge.text?.isEmpty == false && textfield_EmpGender.text?.isEmpty == false && textfield_EmpDesignation.text?.isEmpty == false && textfield_EmpShift.text?.isEmpty == false && textfield_EmpAddress.text?.isEmpty == false)
        {
            let alertController = UIAlertController(title: "Hospital Management", message: "Do you really want to add this employee?", preferredStyle: UIAlertControllerStyle.alert)
            
            alertController.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.destructive) {
                (result : UIAlertAction) -> Void in
                
                MainFile.empName.append(self.textfield_EmpName.text!)
                MainFile.empAge.append(self.textfield_EmpAge.text!)
                MainFile.empGender.append(self.textfield_EmpGender.text!)
                MainFile.empDesignation.append(self.textfield_EmpDesignation.text!)
                MainFile.empShift.append(self.textfield_EmpShift.text!)
                MainFile.empAddress.append(self.textfield_EmpAddress.text!)

                self.navigationController?.popViewController(animated: true)
            })
            alertController.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default))
            
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Hospital Management", message: "Please fill all fields to perform this operation.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
}
