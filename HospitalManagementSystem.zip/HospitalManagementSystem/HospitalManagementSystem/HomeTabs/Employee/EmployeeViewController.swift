//
//  EmployeeViewController.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class EmployeeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var tableview_Employee: UITableView!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        title = "EMPLOYEE"
        
        navigationBarButton()
        
        tableview_Employee.delegate = self
        tableview_Employee.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        DispatchQueue.main.async
        {
            self.tableview_Employee.reloadData()
        }
    }
    
    func navigationBarButton()
    {
        //Left bar button item
        let leftButton : UIBarButtonItem = UIBarButtonItem(title: "BACK", style: UIBarButtonItemStyle.plain, target: self, action: #selector(leftButtonTapped))
        leftButton.tintColor = UIColor.black
        
        self.navigationItem.leftBarButtonItem = leftButton
        //Ends
        
        //RIght bar button item
        let rightButton : UIBarButtonItem = UIBarButtonItem(title: "ADD", style: UIBarButtonItemStyle.plain, target: self, action: #selector(rightButtonTapped))
        rightButton.tintColor = UIColor.black
        
        self.navigationItem.rightBarButtonItem = rightButton
        //Ends
    }
    
    @objc func leftButtonTapped()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func rightButtonTapped()
    {
        self.performSegue(withIdentifier: "addempview", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if(segue.identifier == "addempview")
        {
            let addempview = segue.destination as! AddEmployeeViewController
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return MainFile.empName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellidentifier_Employee") as! EmployeeTableViewCell
        
        cell.label_EmpName.text = MainFile.empName[indexPath.row]
        cell.label_EmpAge.text = MainFile.empAge[indexPath.row]
        cell.label_EmpGender.text = MainFile.empGender[indexPath.row]
        cell.label_EmpAddress.text = MainFile.empAddress[indexPath.row]
        cell.label_EmpShift.text = MainFile.empShift[indexPath.row]
        cell.label_EmpDesignation.text = MainFile.empDesignation[indexPath.row]

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 200.0
    }
}
