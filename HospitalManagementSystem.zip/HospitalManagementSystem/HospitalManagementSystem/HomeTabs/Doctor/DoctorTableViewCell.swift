//
//  DoctorTableViewCell.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class DoctorTableViewCell: UITableViewCell
{
    @IBOutlet weak var label_DocName: UILabel!
    @IBOutlet weak var label_DocDept: UILabel!

    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
