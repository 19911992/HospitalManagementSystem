//
//  DoctorViewController.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class DoctorViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var tableview_Doctor: UITableView!
   
    override func viewDidLoad()
    {
        super.viewDidLoad()

        title = "DOCTOR"
        
        tableview_Doctor.delegate = self
        tableview_Doctor.dataSource = self
        
        navigationBarButton()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        DispatchQueue.main.async
        {
            self.tableview_Doctor.reloadData()
        }
    }
    
    func navigationBarButton()
    {
        //Left bar button item
        let leftButton : UIBarButtonItem = UIBarButtonItem(title: "BACK", style: UIBarButtonItemStyle.plain, target: self, action: #selector(leftButtonTapped))
        leftButton.tintColor = UIColor.black
        
        self.navigationItem.leftBarButtonItem = leftButton
        //Ends
        
        //Left bar button item
        let rightButton : UIBarButtonItem = UIBarButtonItem(title: "ADD", style: UIBarButtonItemStyle.plain, target: self, action: #selector(rightButtonTapped))
        rightButton.tintColor = UIColor.black
        
        self.navigationItem.rightBarButtonItem = rightButton
        //Ends
    }
    
    @objc func leftButtonTapped()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func rightButtonTapped()
    {
        self.performSegue(withIdentifier: "adddocview", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "adddocview")
        {
            var adddocview = segue.destination as! AddDocViewController
        }
    }
    
    //Table view delegate methods starts
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return MainFile.docName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellidentifier_doc") as! DoctorTableViewCell
        
        cell.label_DocName.text = MainFile.docName[indexPath.row]
        cell.label_DocDept.text = MainFile.docDept[indexPath.row]

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 70.0
    }
    //Table view delegate method ends
}
