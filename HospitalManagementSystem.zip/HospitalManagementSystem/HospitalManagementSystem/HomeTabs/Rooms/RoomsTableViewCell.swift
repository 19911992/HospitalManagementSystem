//
//  RoomsTableViewCell.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-10.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class RoomsTableViewCell: UITableViewCell
{
    @IBOutlet weak var label_RoomNo: UILabel!
    @IBOutlet weak var label_RoomPrice: UILabel!
    @IBOutlet weak var label_RoomAssignedTo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
