//
//  RoomsViewController.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class RoomsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var tableview_Rooms: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        title = "ROOMS"
        
        navigationBarButton()
        
        tableview_Rooms.delegate = self
        tableview_Rooms.dataSource = self
    }
    
    func navigationBarButton()
    {
        //Left bar button item
        let leftButton : UIBarButtonItem = UIBarButtonItem(title: "BACK", style: UIBarButtonItemStyle.plain, target: self, action: #selector(leftButtonTapped))
        leftButton.tintColor = UIColor.black
        
        self.navigationItem.leftBarButtonItem = leftButton
        //Ends
    }
    
    @objc func leftButtonTapped()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return MainFile.roomNo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellidentifier_Rooms") as! RoomsTableViewCell
        
        cell.label_RoomNo.text = MainFile.roomNo[indexPath.row]
        cell.label_RoomPrice.text = MainFile.roomAmount[indexPath.row]
        cell.label_RoomAssignedTo.text = MainFile.roomAssignedToPat[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 100.0
    }
}
