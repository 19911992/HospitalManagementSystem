//
//  MainFile.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

class MainFile
{
    static var docName : [String] = ["John", "Dwane"]
    static var docDept : [String] = ["Surgery", "Orthodox"]
    
    static var patName : [String] = ["Vishal", "Guru", "Puneet"]
    static var patAge : [String] = ["25", "26", "25"]
    static var patSex : [String] = ["M", "M", "M"]
    static var patAddress : [String] = ["Hno 37", "Hno 38", "Hno 39"]
    static var patArrivalDate : [String] = ["2017-01-10", "2017-01-10", "2017-03-16"]
    
    static var empName : [String] = ["Laura", "Justin", "Maxime"]
    static var empGender : [String] = ["F", "M", "M"]
    static var empAge : [String] = ["25", "27", "28"]
    static var empAddress : [String] = ["Finch", "Kiskadee", "Martin Grove"]
    static var empShift : [String] = ["Day", "Night", "Night"]
    static var empDesignation : [String] = ["Assistant", "Ward Boy", "Ward Boy"]
    
    static var billDate : [String] = ["2017-01-15", "2017-02-18", "2017-03-20"]
    static var billAmount : [String] = ["750", "400", "300"]
    static var billPatName : [String] = ["Vishal", "Guru", "Puneet"]
    static var billPatRoom : [String] = ["3", "2", "1"]
    static var billPatAssignDoc : [String] = ["John", "John", "Dwane"]
    
    static var medName : [String] = ["Paracetamol", "Disprin", "Solvin Cold", "Revital", "Bruffin"]
    static var medQuantity : [String] = ["50", "40", "30", "20", "25"]
    static var medPrice : [String] = ["35", "40", "45", "35", "30"]
    
    static var roomNo : [String] = ["101", "102", "103"]
    static var roomAmount : [String] = ["$150", "$250", "$100"]
    static var roomAssignedToPat : [String] = ["Vishal", "Guru", "Puneet"]
}
