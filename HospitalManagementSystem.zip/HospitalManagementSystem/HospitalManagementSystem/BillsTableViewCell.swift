//
//  BillsTableViewCell.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-10.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class BillsTableViewCell: UITableViewCell
{
    @IBOutlet weak var label_billsAmount: UILabel!
    @IBOutlet weak var label_billsRoomNo: UILabel!
    @IBOutlet weak var label_billsPatName: UILabel!
    @IBOutlet weak var label_billsAssignedDoc: UILabel!
    @IBOutlet weak var label_billsDate: UILabel!

    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
