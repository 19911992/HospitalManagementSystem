//
//  ViewController.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var textfield_EmailId: UITextField!
    @IBOutlet weak var textfield_Pwd: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        title = "LOGIN"
        
        //Getures
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.gestureMethod(_:)))
        view.addGestureRecognizer(tapGesture)
        //End
    }
    
    @objc func gestureMethod(_ sender: UITapGestureRecognizer)
    {
        self.view.endEditing(true)
    }
    
    @IBAction func btn_Login(_ sender: UIButton)
    {
        self.view.endEditing(true)
        if(textfield_EmailId.text == "")
        {
            let alert = UIAlertController(title: "Hospital Management", message: "Please enter your Email-Id.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if(textfield_Pwd.text == "")
        {
            let alert = UIAlertController(title: "Hospital Management", message: "Please enter your Password.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            let landingview:UIViewController =  (self.storyboard?.instantiateViewController(withIdentifier: "landingview") as? LandingView)!
            self.navigationController?.pushViewController(landingview, animated: false)
        }
    }
}
