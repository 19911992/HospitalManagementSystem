//
//  LandingView.swift
//  HospitalManagementSystem
//
//  Created by Vishal Verma on 2017-11-08.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class LandingView: UIViewController
{
    @IBOutlet weak var imgview_Bills: UIImageView!
    @IBOutlet weak var imgview_Medicines: UIImageView!
    @IBOutlet weak var imgview_Doc: UIImageView!
    @IBOutlet weak var imgview_Rooms: UIImageView!
    @IBOutlet weak var imgview_Patient: UIImageView!
    @IBOutlet weak var imgview_Emp: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        title = "HOME"
        self.navigationItem.hidesBackButton = true
        
        navigationBarButton()
        
        imgview_Bills.isUserInteractionEnabled = true
        imgview_Medicines.isUserInteractionEnabled = true
        imgview_Doc.isUserInteractionEnabled = true
        imgview_Rooms.isUserInteractionEnabled = true
        imgview_Patient.isUserInteractionEnabled = true
        imgview_Emp.isUserInteractionEnabled = true

        imageTapGestures()
    }
    
    func navigationBarButton()
    {
        //Right bar button item
        let rightButton : UIBarButtonItem = UIBarButtonItem(title: "LOGOUT", style: UIBarButtonItemStyle.plain, target: self, action: #selector(rightButtonTapped))
        rightButton.tintColor = UIColor.black
        
        self.navigationItem.rightBarButtonItem = rightButton
        //Ends
    }
    
    @objc func rightButtonTapped()
    {
        let alertController = UIAlertController(title: "Hospital Management", message: "Do you really want to logout?", preferredStyle: UIAlertControllerStyle.alert)
        
        alertController.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.destructive)
        {
            (result : UIAlertAction) -> Void in
            self.navigationController?.popToRootViewController(animated: true)
        })
        alertController.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default))
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func imageTapGestures()
    {
        //Getures
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(self.gestureMethod1(_:)))
        imgview_Doc.addGestureRecognizer(tapGesture1)
        //End
        
        //Getures
        let tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(self.gestureMethod2(_:)))
        imgview_Patient.addGestureRecognizer(tapGesture2)
        //End
        
        //Getures
        let tapGesture3 = UITapGestureRecognizer(target: self, action: #selector(self.gestureMethod3(_:)))
        imgview_Emp.addGestureRecognizer(tapGesture3)
        //End
        
        //Getures
        let tapGesture4 = UITapGestureRecognizer(target: self, action: #selector(self.gestureMethod4(_:)))
        imgview_Bills.addGestureRecognizer(tapGesture4)
        //End
        
        //Getures
        let tapGesture5 = UITapGestureRecognizer(target: self, action: #selector(self.gestureMethod5(_:)))
        imgview_Medicines.addGestureRecognizer(tapGesture5)
        //End
        
        //Getures
        let tapGesture6 = UITapGestureRecognizer(target: self, action: #selector(self.gestureMethod6(_:)))
        imgview_Rooms.addGestureRecognizer(tapGesture6)
        //End
    }
    
    @objc func gestureMethod1(_ sender: UITapGestureRecognizer)
    {
        self.performSegue(withIdentifier: "doctorview", sender: self)
    }
    
    @objc func gestureMethod2(_ sender: UITapGestureRecognizer)
    {
        self.performSegue(withIdentifier: "patientview", sender: self)
    }
    
    @objc func gestureMethod3(_ sender: UITapGestureRecognizer)
    {
        self.performSegue(withIdentifier: "empview", sender: self)
    }
    
    @objc func gestureMethod4(_ sender: UITapGestureRecognizer)
    {
        self.performSegue(withIdentifier: "billsview", sender: self)
    }
    
    @objc func gestureMethod5(_ sender: UITapGestureRecognizer)
    {
        self.performSegue(withIdentifier: "medicineview", sender: self)
    }
    
    @objc func gestureMethod6(_ sender: UITapGestureRecognizer)
    {
        self.performSegue(withIdentifier: "roomview", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if(segue.identifier == "doctorview")
        {
            segue.destination as! DoctorViewController
        }
        else if(segue.identifier == "patientview")
        {
            segue.destination as! PatientViewController
        }
        else if(segue.identifier == "empview")
        {
            segue.destination as! EmployeeViewController
        }
        else if(segue.identifier == "billsview")
        {
            segue.destination as! BillsViewController
        }
        else if(segue.identifier == "medicineview")
        {
            segue.destination as! MedicineViewController
        }
        else if(segue.identifier == "roomview")
        {
            segue.destination as! RoomsViewController
        }
    }
}
